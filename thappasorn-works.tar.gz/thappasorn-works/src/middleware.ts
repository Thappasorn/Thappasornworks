import createMiddleware from "next-intl/middleware";
import { routing } from "./i18n/routing";

export default createMiddleware(routing);

export const config = {
  // Run on everything except API, static files and Next internals
  matcher: ["/((?!api|_next|_vercel|.*\\..*).*)"],
};
